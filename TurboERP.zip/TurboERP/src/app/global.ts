//
// ===== File globals.ts    
//
'use strict';

export const sep='/';
export const version: string="22.2.2";  