export class ManufacturingUnitModel
{
    public PID : number;
    public COMPANYUNIT : string;
    public MANF_NAME : string;
}