export class CountryMasterModel
{
public PID:number
public COUN_CODE:string
public COUN_NAME:string
public CONT_CODE:string
}

export class ContinentModel
{
    public CONT_CODE : string
    public CONT_NAME : string
}