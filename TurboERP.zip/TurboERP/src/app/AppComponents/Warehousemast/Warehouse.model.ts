export class WarehouseMast {
 PID: number
COMPANY_PID: string
WAREHOUSE_NAME:string
ADDRESS :string
}


export class Comp {
    Pid: number
   Value: String
   
   }

   