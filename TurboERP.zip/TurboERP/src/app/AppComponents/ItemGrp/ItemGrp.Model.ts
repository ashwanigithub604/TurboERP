export class ItemGrpModel
{
    public PID:number
    public GRP_CODE:string
    public GRP_NAME:string
    public GRP_PREFIX:string
    public PICT_PATH:string

}