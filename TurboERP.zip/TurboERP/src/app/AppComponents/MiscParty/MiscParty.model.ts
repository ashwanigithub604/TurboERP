export class MiscPartyModel {


   
    public PID: string
    public TYPE: string
    public NAME: string
    public SHORT_NAME: string
    public ADD1: string
    public ADD2: string
    public ADD3: string
    public CONTPER: string
    public WEB_ADD: string
    public EMAIL: string
    public MOBILE: string
    public PHONE: string
    public RELA: string
    public FAX: string
    public REMARKS:Date
    public MISCTYPE: string
    public INPUT_BY: string
    public INPUT_DATE: string
    public EDIT_DATE: string
    public CODE: string
}
export class PartyType
{
    public  PID :number
    public  Party_Description :string
    public Type:string

}
