export class CourierModel
{
    public PID: string
    public NAME: string
    public SHORT_NAME: string
    public ADD1: string
    public ADD2: string
    public ADD3: string
    public CONTPER: string
    public WEB_ADD: string
    public EMAIL: string
    public MOBILE: string
    public PHONE: string
    public RELA: Date
    public FAX: string
    public REMARKS:string
    public MISCTYPE: string
    public CODE: string
}