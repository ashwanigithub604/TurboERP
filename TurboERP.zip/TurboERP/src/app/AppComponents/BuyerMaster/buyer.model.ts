
export class BuyerMast {
        PID: number
        BUYER_CODE   : string
        TALLYID   : string
        BUYER_NAME   : string
        SHORT_NAME   : string
        ADD1   : string   //
        ADD2   : string  //
        ADD3   : string  //
        ADD4   : string  //
        ADD5   : string  //
        COUN_CODE   : string
        CURR_CODE   : string
        BANK_ADD1   : string  //
        BANK_ADD2   : string  //
        BANK_ADD3   : string  //
        BANK_ADD4   : string  //
        PORT_DISC   : string
        FIN_DEST   : string
        NOTIFY1   : string
        NOTIFY2   : string
        NOTIFY3   : string
        NOTIFY4   : string
        NOTIFY5   : string
        NOTIFY6   : string
        NOTIFY7   : string
        NOTIFY8   : string
        NOTIFY9   : string
        NOTIFY10   : string
        PHONE   : string
        MOBILE   : string
        EMAIL   : string
        FAX   : string
        AGNT_CODE   : string
        TYPE   : string
        CMSN :number
        CNT_PRSN   : string
        PAY_TERM1   : string
        PAY_TERM2   : string
        PAY_TERM3   : string
        PAY_TERM4   : string
        PAY_TERM5   : string
        PAY_TERM6   : string
        PAY_TERM7   : string
        PAY_TERM8   : string
        OPEN_BAL:number
        DEAL_ITM   : string
        VISITOR   : string
        VISIT_ADD1   : string
        VISIT_ADD2   : string
        VISIT_ADD3   : string
        RMK5   : string
        BANK_ACNO   : string  //
        SWIFT_ACNO   : string  //
        RELA_SINCE :Date
        SOURCE   : string
        CAT_CODE   : string
        WEB_ADDR   : string
        BANKCODE   : string
        MER_CODE   : string
        FREEZE   : boolean
        BUY_FWRD   : string
        CITY_CODE   : string
        OTHER_REF   : string
        STATE_CODE   : string
        GSTPRIFIX   : string
        GSTIN_CAT   : boolean
        GSTIN_NO   : string
        GST_REG   : string
}

export class courier{

}