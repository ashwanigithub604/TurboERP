export class CurrMastModel
{
    public PID: Number
    public CURR_CODE: string
    public CURR_NAME: string
    public CURR_CAP: string
    public CURR_CONV: number
    public EXC_RATE: number
    public COIN: string
    public CURR_SEP: string
}