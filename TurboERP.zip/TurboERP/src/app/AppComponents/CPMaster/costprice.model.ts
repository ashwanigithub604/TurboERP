export class CPMaster {
    PID: number
    CP_CODE: string
    RATE:number
}