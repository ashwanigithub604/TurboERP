export class UnitMast {
    PID: number
    UNIT: string
    DESC:string
    DECI_REQ: boolean
}