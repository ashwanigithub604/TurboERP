export class CartPlyModel
{
public PID:number
public CRTN_PLY:number
public RATEBROWN:number
public RATECOLOR:number
public BOARDWIDTH:number
}